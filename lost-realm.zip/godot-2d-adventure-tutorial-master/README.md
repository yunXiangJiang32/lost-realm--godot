# Godot 2D 横版动作游戏教程

Godot 4 入门视频教程。

## 素材来源

* 玩家精灵 https://brullov.itch.io/generic-char-asset
* 环境敌人 https://anokolisa.itch.io/sidescroller-pixelart-sprites-asset-pack-forest-16x16
* 按键提示 https://greatdocbrown.itch.io/gamepad-ui
* 字体素材 https://atelier-anchor.com/typefaces/smiley-sans
* 音效素材 https://www.kenney.nl/assets/impact-sounds https://leohpaz.itch.io/minifantasy-dungeon-sfx-pack
* 音乐素材 https://sonatina.itch.io/infinity-crystal
